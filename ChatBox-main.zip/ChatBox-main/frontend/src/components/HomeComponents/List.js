import React from 'react'

export default function List({text}) {
  return (
    <div className="bg-green-600 text-white">{text}</div>
  )
}
